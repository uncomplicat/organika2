<?php
header('Location: /jocms/control/cms.php');
?>
