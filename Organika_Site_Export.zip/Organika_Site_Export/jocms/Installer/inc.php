<?php
require_once('../core/inc/settings.php');
$JO_LANG = array_merge($JO_LANG,jo_language($JO_S['lang'],"/jocms/Installer/"));
 ?>
